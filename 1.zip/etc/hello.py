# Начальная конфигурация gunicorn Hello-world
pythonpath = '/home/box/web'
bind = "0.0.0.0:8080"
workers = 4
timeout = 1

