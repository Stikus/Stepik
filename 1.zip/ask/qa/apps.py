from django.apps import AppConfig


class QaConfig(AppConfig):
    name = 'qa'
