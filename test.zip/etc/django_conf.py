
#А это для Django
pythonpath = '/home/box/web/ask'
bind = "0.0.0.0:8000"
workers = 4
